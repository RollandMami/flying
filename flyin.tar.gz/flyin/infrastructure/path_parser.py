from abc import ABC, abstractmethod
from typing import Any, Optional
from enum import Enum
import importlib

try:
    pydantic = importlib.import_module("pydantic")
    BaseModel = pydantic.BaseModel
    Field = pydantic.Field
    ValidationError = pydantic.ValidationError
    model_validator = pydantic.model_validator
    field_validator = pydantic.field_validator
except (ModuleNotFoundError, ImportError) as e:
    raise ModuleNotFoundError(f"{type(e).__name__}: {e}")


class Zone(str, Enum):
    NORMAL = "normal"
    BLOCKED = "blocked"
    RESTRICTED = "restricted"
    PRIORITY = "priority"


class Meta(BaseModel):
    color: str | None = Field(default=None)
    max_drones: int = Field(default=1, ge=1)
    zone: Zone = Field(default=Zone.NORMAL)


class Hub(BaseModel):
    name: str
    x: float
    y: float
    meta: Meta = Field(default_factory=Meta)


class Con(BaseModel):
    left: str
    right: str
    max_link_capacity: Optional[int] = Field(default=1, ge=1)


class MapModel(BaseModel):
    drone_number: int
    start_hub: Hub
    hubs: list[Hub] = Field(default_factory=list)
    end_hub: Hub
    connections: list[Con] = Field(default_factory=list)

    @model_validator(mode="after")
    def check_connections_reference_known_hubs(self) -> "MapModel":
        known_names = {h.names for h in self.hubs}
        known_names.add(self.start_hub.name)
        known_names.add(self.end_hub.name)

        for c in self.connections:
            if c.left not in known_names:
                raise ValueError(f"Connection ref unknown: {c.left}")
            if c.right not in known_names:
                raise ValueError(f"Connection ref unknown: {c.right}")
        return self

    def get_hub(self, name: str) -> Hub:
        if self.start_hub.name == name:
            return self.start_hub
        if self.end_hub.name == name:
            return self.end_hub
        for h in self.hubs:
            if h.name == name:
                return h
        raise KeyError(name)


class BaseParser(ABC):
    @abstractmethod
    def load(self, path: str) -> dict[str, Any]:
        ...


class TxtParser(BaseParser):

    def __init__(self) -> None:
        self._path: str | None = None
        self._result: dict[str, Any] = {}
        self._keys: set[str] = {
            "nb_drones",
            "start_hub",
            "hub",
            "end_hub",
            "connection"
        }

    def set_path(self, path: str) -> None:
        if not path or len(path) <= 2:
            raise ValueError(f"Path errror : {path}")
        self._path = path

    @staticmethod
    def parse_options(text: str) -> dict[str, Any]:
        text = text.strip()
        if not text:
            return {}
        text = text.replace("[", "").replace("]", "")
        options: dict[str, Any] = {}
        for pair in text.split():
            if "=" not in pair:
                print(f"Bad syntax: {pair}, must include '='")
                continue
            key, value = pair.split("=", 1)
            key, value = key.strip(), value.strip()
            if value.lstrip("-").isdigit():
                options[key] = int(value)
            else:
                options[key] = value
        return options

    def _split_head_and_options(self, arg: str) -> tuple[str, str]:
        index = arg.find("[")
        if index == -1:
            return arg.strip(), ""
        return arg[:index].strip(), arg[index:].strip()

    def parse_hub_line(self, arg: str) -> dict[str, Any]:
        head, opts_str = self._split_head_and_options(arg)
        tokens = head.split()
        if len(tokens) < 3:
            raise ValueError(f"Malformed hub line: '{arg}'")
        name, x, y = tokens[0], float(tokens[1]), float(tokens[2])
        if "-" in name:
            raise ValueError(f"Malformed hub line: '{arg}'")
        return {
            "name": name,
            "x": x,
            "y": y,
            "meta": self.parse_options(opts_str)
        }

    def parse_connection_line(self, arg: str) -> dict[str, Any]:
        head, opts_str = self._split_head_and_options(arg)
        if "-" not in head:
            raise ValueError(f"Malformed connection line: '{arg}'")
        left, right = head.split("-", 1)
        data: dict[str, Any] = {"left": left.strip(), "right": right.strip()}
        data.update(self.parse_options(opts_str))
        return data

    def load(self, path: str) -> dict[str, Any]:
        if not self._path:
            raise ValueError("Path must be valid path name")

        try:
            self.set_path(path)
            result: dict[str, Any] = {"hubs": [], "connections": []}
            with open(self._path, "r") as maps:
                for raw_line in maps:
                    line = raw_line.strip()
                    if line.startswith("#") or not line:
                        continue
                    if ":" not in line:
                        raise ValueError("Bad line format, must include ':'")
                    label, arg = line.split(":")
                    label, arg = label.strip(), arg.strip()
                    if label not in self._keys:
                        raise ValueError(f"Unknown label '{label}'")
                    if "nb" in label:
                        self._result["nb_drones"] = int(arg)
                    elif "start" in label:
                        result["start_hub"] = self.parse_hub_line(arg)
                    elif "end" in label:
                        result["end_hub"] = self.parse_hub_line(arg)
                    elif label == "hub":
                        result["hubs"].append(self.parse_hub_line(arg))
                    elif label == "connection":
                        result["connections"].append(self.parse_connection_line(arg))
            self._result = result
            return result
        except Exception as e:
            raise Exception(e)
